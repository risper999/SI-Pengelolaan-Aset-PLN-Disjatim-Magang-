# ADS_1_C
Kelompok 1 ADS
